<?php
session_start();
include('verifica_login.php');
?>
<?php
$usuario_cadastro = $_SESSION['usuario'];
print '<p>';
print 'Olá: ';
print $usuario_cadastro;
print '<p>';
print 'Seja Bem Vindo(a).';

?> 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">        
    <link rel="stylesheet" href="css/bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css">
	<link rel="stylesheet" href="./style.css">	
	<link rel="stylesheet" href="./style3.css">	
</head>
<script>  

    
function maiuscula(z){
        v = z.value.toUpperCase();
        z.value = v;
    }
	
function Mascara_Hora(hora){ 
var hora01 = ''; 
hora01 = hora01 + hora; 
if (hora01.length == 2){ 
hora01 = hora01 + ':'; 
document.forms[0].hora_inicio.value = hora01; 
} 
if (hora01.length == 5){ 
Verifica_Hora(); 
} 
} 
           
function Verifica_Hora(){ 
hrs = (document.forms[0].hora_inicio.value.substring(0,2)); 

min = (document.forms[0].hora_inicio.value.substring(3,5)); 
               
               
estado = ""; 
if ((hrs < 00 ) || (hrs > 23) || ( min < 00) ||( min > 59)){ 
estado = "errada"; 
} 
               
if (document.forms[0].hora_inicio.value == "") { 
estado = "errada"; 
} 



if (estado == "errada") { 
alert("Por Favor, Verifique os valores de Hora Inicial !"); 
document.forms[0].hora_inicio.focus(); 
} 
} 



function Mascara_Hora2(Hora){ 
var hora01 = ''; 
hora01 = hora01 + Hora; 
if (hora01.length == 2){ 
hora01 = hora01 + ':'; 
document.forms[0].hora_final.value = hora01; 
} 
if (hora01.length == 5){ 
Verifica_Hora2(); 
} 
} 
           
function Verifica_Hora2(){ 
hrs = (document.forms[0].hora_final.value.substring(0,2)); 

min = (document.forms[0].hora_final.value.substring(3,5)); 
               
               
estado2 = ""; 
if ((hrs < 00 ) || (hrs > 23) || ( min < 00) ||( min > 59)){ 
estado2 = "errada"; 
} 
               
if (document.forms[0].hora_final.value == "") { 
estado2 = "errada"; 
} 



if (estado2 == "errada") { 
alert("Por Favor, Verifique os valores de Hora Final!"); 
document.forms[0].hora_final.focus(); 
} 
} 
function mascaraData(campoData){
              var data = campoData.value;
              if (data.length == 2){
                  data = data + '/';
                  document.forms[0].data.value = data;
      return true;              
              }
              if (data.length == 5){
                  data = data + '/';
                  document.forms[0].data.value = data;
                  return true;
              }
         }
//-->
</script>
<nav class="nav">
<ul>


			<ul class="dropdown">				
</ul>
<li><a href="../../control_pass/menu.php">||Menu||</a></li>
<li><a href="init.php">Home</a></li>
<li><a href="resumotecnologia.php">Resumo</a></li>							
<li><a href="detalhamento_geral.php">Detalhamento</a></li>							
<li><a href="lista_registro.php">Excluir</a></li>							
<li><a href="logout.php">Sair</a></li>							

</li>
</ul>
</nav>

            <div class="column is-4 is-offset-4">
                    <h1 class="title has-text-grey">BANCO DE HORAS</h1>
					<h2 class="title has-text-grey"><font size=4><center>[Tecnologia da Informação]</font></h2>                   				


                    <div class="box">
					<p align=left>					
				   <img src=css/logo.png><br></p>
				   <center>
					<font size=2>
                
					<?php

include "sql.php";
       
if(isset($_POST['done'])){   

    $nome = $_POST['nome'];
	$hora_inicio = $_POST['hora_inicio'];
    $hora_final = $_POST['hora_final'];
	$descricao = $_POST['descricao'];
	$tipo = $_POST['tipo'];
	$faixa = $_POST['faixa'];
	$data = $_POST['data'];
	$validar_data =$data;	
	$data_atual = date('d/m/Y', strtotime('-3 days'));
	
	$data_atual = DateTime::createFromFormat('d/m/Y', $data_atual);
	$validar_data = DateTime::createFromFormat('d/m/Y', $validar_data);
	if ($validar_data <> ''){
	
	if ($validar_data < $data_atual){		
	print'<font color=red size=4>';
	echo "<script>alert('DATA NÃO PODE SER MENOR QUE 3 DIAS, VERIFIQUE SE A DATA ESTA NO FORMATO DD/MM/AAAA EX: 01/01/2017!');</script>";
	   
	   $nome='';
	   print '</font>';
    }
}		
	

    

	
 

    if(empty($nome) || empty($hora_inicio) || empty($hora_final)|| empty($descricao)| empty($data)){

        $erro = "Atenção, você deve preencher todos os campos ou o nome de usuario não pode ser recuperado";
			
		}else{        

       $sql = mysql_query("INSERT INTO `banco_horas`(`data`,`nome`, `hora_inicio`, `hora_final`, `descricao`, `horas_baixa`,`usuario`,`faixa`,`ip`,`data_criacao`) VALUES ('$data','$nome', '$hora_inicio', '$hora_final','$descricao','$tipo','$usuario','$faixa','$ip',now())") or die(mysql_error());

            if($sql){

                $erro2 = "Dados cadastrados com sucesso!";
	
				

              } else{

                  $erro = "Não foi possivel cadastrar os dados";

              }

    }

}

?>



<form name="form1" action="init.php" method="POST" style="padding-top:40px;">

<?php

if(isset($erro)){

    print '<div style="width:80%; background:red; color:Black; padding: 5px 0px 5px 0px; text-align:center; margin: 0 auto;">'.$erro.'</div>';

}


if(isset($erro2)){

    print '<div style="width:80%; background:green; color:Black; padding: 5px 0px 5px 0px; text-align:center; margin: 0 auto;">'.$erro2.'</div>';

}

?>

<tr>
<td><select name="nome" class="input is-large" id="nome" >
<option>SELECIONE O COLABORADOR</option>
<option>VANDERLEI</option>
<option>ESTAGIARIO</option>
</select>
</td>

</tr>
<tr>

<td><input name="hora_inicio" type="text" class="input is-large"  placeholder="Hora Inicio" maxlength="5" OnKeyUp="Mascara_Hora(this.value)" id="hora_inicio" /></td>
</tr>
<tr>
<td><input name="hora_final" type="text" class="input is-large" placeholder="Hora Final" maxlength="5" OnKeyUp="Mascara_Hora2(this.value)" id="hora_final" /></td>
</tr>
<tr>
<td><input name="data" type="text" class="input is-large"  placeholder="Data (Máximo 3 Dias Anteriores)" id="data" OnKeyUp="mascaraData(this);" maxlength="10" /></td> 
<tr>
<td><input name="descricao" type="text" class="input is-large" placeholder="Observações" onkeyup="maiuscula(this)" id="descricao" /></td>
</tr>
<tr>
<td><select name="tipo" class="input is-large">	
<option>SELECIONE O REGISTRO</option>
<option>BANCO_HORAS</option>
<option>FOLGA</option>		      
</select>
 </td>
</tr>
<td><input type="submit" class="button is-block is-link is-large is-fullwidth" value="Cadastrar" onclick="if(!confirm('Tem certeza que deseja Cadastrar?'))return false;" /><input type="hidden" name="done"  value="" /></td>
</tr>
</tbody>
</table>
</form>
<!-- Rounded switch -->
<label class="switch" onClick="window.location.href='../init.php';">>
  <input type="checkbox">
  <span class="slider round"></span>
</label>Vintage Visual
					</div>
                </div>
            </div>
        </div>
  
    </section>
	

</body>
</html>
