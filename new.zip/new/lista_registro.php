<?php
session_start();
include('verifica_login.php');
?>
<?php
$usuario_cadastro = $_SESSION['usuario'];
print '<p>';
print 'Olá: ';
print $usuario_cadastro;
print '<p>';
print 'Seja Bem Vindo(a).';

?> 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">        
    <link rel="stylesheet" href="css/bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css">
	<link rel="stylesheet" href="./style.css">	
	<link rel="stylesheet" href="./style3.css">	
</head>
<script>  

    
function maiuscula(z){
        v = z.value.toUpperCase();
        z.value = v;
    }
	
function Mascara_Hora(hora){ 
var hora01 = ''; 
hora01 = hora01 + hora; 
if (hora01.length == 2){ 
hora01 = hora01 + ':'; 
document.forms[0].hora_inicio.value = hora01; 
} 
if (hora01.length == 5){ 
Verifica_Hora(); 
} 
} 
           
function Verifica_Hora(){ 
hrs = (document.forms[0].hora_inicio.value.substring(0,2)); 

min = (document.forms[0].hora_inicio.value.substring(3,5)); 
               
               
estado = ""; 
if ((hrs < 00 ) || (hrs > 23) || ( min < 00) ||( min > 59)){ 
estado = "errada"; 
} 
               
if (document.forms[0].hora_inicio.value == "") { 
estado = "errada"; 
} 



if (estado == "errada") { 
alert("Por Favor, Verifique os valores de Hora Inicial !"); 
document.forms[0].hora_inicio.focus(); 
} 
} 



function Mascara_Hora2(Hora){ 
var hora01 = ''; 
hora01 = hora01 + Hora; 
if (hora01.length == 2){ 
hora01 = hora01 + ':'; 
document.forms[0].hora_final.value = hora01; 
} 
if (hora01.length == 5){ 
Verifica_Hora2(); 
} 
} 
           
function Verifica_Hora2(){ 
hrs = (document.forms[0].hora_final.value.substring(0,2)); 

min = (document.forms[0].hora_final.value.substring(3,5)); 
               
               
estado2 = ""; 
if ((hrs < 00 ) || (hrs > 23) || ( min < 00) ||( min > 59)){ 
estado2 = "errada"; 
} 
               
if (document.forms[0].hora_final.value == "") { 
estado2 = "errada"; 
} 



if (estado2 == "errada") { 
alert("Por Favor, Verifique os valores de Hora Final!"); 
document.forms[0].hora_final.focus(); 
} 
} 
function mascaraData(campoData){
              var data = campoData.value;
              if (data.length == 2){
                  data = data + '/';
                  document.forms[0].data.value = data;
      return true;              
              }
              if (data.length == 5){
                  data = data + '/';
                  document.forms[0].data.value = data;
                  return true;
              }
         }
//-->
</script>
<nav class="nav">
<ul>

<li class="drop"><a href="#"></a>
			<ul class="dropdown">				
</ul>
<li><a href="init.php">Home</a></li>
<li><a href="resumotecnologia.php">Resumo</a></li>							
<li><a href="detalhamento_geral.php">Detalhamento</a></li>							
<li><a href="lista_registro.php">Excluir</a></li>							
<li><a href="logout.php">Sair</a></li>							

</li>
</ul>
</nav>

            <br>
                    <h1 class="title has-text-grey">BANCO DE HORAS</h1>
					<h2 class="title has-text-grey"><font size=4><center>[Tecnologia da Informação]</font></h2>                   				


                    <div class="box">
					<p align=left>					
				   <img src=css/logo.png><br></p>
				   <center>
					<font size=2>
                
					
<?php
include "sql.php";
$max = 50;
$pagina = $_GET['pagina'];
if(!$pagina){

	$inicio = 0;

	$pagina = 1;

}else{

$inicio = ($pagina - 1) * $max;

}
$sqln = mysql_query("SELECT * FROM banco_horas ORDER BY id DESC");

$num = mysql_num_rows($sqln);

if($num == 0){

print "Até o momento não temos nenhum registro";

}else{



$total_paginas = ceil($num/$max);



print  "Temos ".$num."  Registros cadastrados.<br>";
print '<br>';
print "Listando a página ".$pagina." de ".$total_paginas."!";



$sqln = mysql_query("SELECT * FROM banco_horas ORDER BY id DESC LIMIT ".$inicio.",".$max."");

$num = mysql_num_rows($sqln);

}

?>

  <?php

  print '<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>

    <td width="10%" align="center" bgcolor="#gray" class="fonte"><font color=black>ID </td>

    <td align="left" bgcolor="#gray" class="fonte"><font color=black>COLABORADOR</td>

    <td align="left" bgcolor="#gray" class="fonte"><font color=black>DESCRIÇÃO<font color=black></td>


    <td colspan="2" align="center" bgcolor="#gray" class="fonte" width="15%"><font color=black>AÇÕES</td>

  </tr>';

  

  for($i = 0; $i < $num; $i++){

  $nome = @mysql_result($sqln, $i, "nome");

  $descricao = @mysql_result($sqln, $i, "descricao");


  $id = @mysql_result($sqln, $i, "id");

  $n = $i + 1;

  $d = $i % 2;

  if($d == 0){$cor = "000000";}else{$cor = "ffffff"; }

  print '<tr class='.$cor.'>';

  print '<td align="center">'.$id.'</td>';

  print '<td>'.$nome.'</td>';

  print '<td>'.$descricao.'</td>';


  

  print '<td align="center"><a href="deleta_registro.php?id='.$id.'">Excluir</a></td>';

  print '</tr>';

  }

  

  print '</table>';

 print '<div style="text-align:center; margin-top: 30px;">';

if($pagina != 1){

print '<a href="lista_registro.php?'. $_SERVER['QUERY_STRING']. "&pagina=".($pagina - 1).'"><< anterior</a>';

}else{

    print '<span style="color: #ccc;"><< anterior </span>';

}

if ($total_paginas > 1){ 

    for ($i=1; $i <= $total_paginas; $i++){ 

       if ($pagina == $i){        

          echo "<span class='al'> [".$pagina."] </span>"; 

       }else{           

          echo "<a href=\"lista_registro.php?" . $_SERVER['QUERY_STRING']."&pagina=".$i."\">&nbsp;".$i."&nbsp;</a> "; 

		  }

    } 

} 

if($pagina < $total_paginas){

print '<a href="lista_registro.php?'. $_SERVER['QUERY_STRING']. "&pagina=".($pagina + 1).'">próxima >></a>';

}else{

    print '<span style="color: #ccc;"> próxima >></span>';

}

print '</div>';

 



        

print '</table>';
  ?>


					</div>
                </div>
            </div>
        </div>
  
    </section>
	

</body>
</html>
