<?php
session_start();
include('verifica_login.php');
?>
<?php
$usuario_cadastro = $_SESSION['usuario'];
print '<p>';
print 'Olá: ';
print $usuario_cadastro;
print '<p>';
print 'Seja Bem Vindo(a).';

?> 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">        
    <link rel="stylesheet" href="css/bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css">
	<link rel="stylesheet" href="./style.css">	
	<link rel="stylesheet" href="./style3.css">	
    <link rel="stylesheet" href="./style4_blockquote.css">	

</head>
<script>  

    
function maiuscula(z){
        v = z.value.toUpperCase();
        z.value = v;
    }
	
function Mascara_Hora(hora){ 
var hora01 = ''; 
hora01 = hora01 + hora; 
if (hora01.length == 2){ 
hora01 = hora01 + ':'; 
document.forms[0].hora_inicio.value = hora01; 
} 
if (hora01.length == 5){ 
Verifica_Hora(); 
} 
} 
           
function Verifica_Hora(){ 
hrs = (document.forms[0].hora_inicio.value.substring(0,2)); 

min = (document.forms[0].hora_inicio.value.substring(3,5)); 
               
               
estado = ""; 
if ((hrs < 00 ) || (hrs > 23) || ( min < 00) ||( min > 59)){ 
estado = "errada"; 
} 
               
if (document.forms[0].hora_inicio.value == "") { 
estado = "errada"; 
} 



if (estado == "errada") { 
alert("Por Favor, Verifique os valores de Hora Inicial !"); 
document.forms[0].hora_inicio.focus(); 
} 
} 



function Mascara_Hora2(Hora){ 
var hora01 = ''; 
hora01 = hora01 + Hora; 
if (hora01.length == 2){ 
hora01 = hora01 + ':'; 
document.forms[0].hora_final.value = hora01; 
} 
if (hora01.length == 5){ 
Verifica_Hora2(); 
} 
} 
           
function Verifica_Hora2(){ 
hrs = (document.forms[0].hora_final.value.substring(0,2)); 

min = (document.forms[0].hora_final.value.substring(3,5)); 
               
               
estado2 = ""; 
if ((hrs < 00 ) || (hrs > 23) || ( min < 00) ||( min > 59)){ 
estado2 = "errada"; 
} 
               
if (document.forms[0].hora_final.value == "") { 
estado2 = "errada"; 
} 



if (estado2 == "errada") { 
alert("Por Favor, Verifique os valores de Hora Final!"); 
document.forms[0].hora_final.focus(); 
} 
} 
function mascaraData(campoData){
              var data = campoData.value;
              if (data.length == 2){
                  data = data + '/';
                  document.forms[0].data.value = data;
      return true;              
              }
              if (data.length == 5){
                  data = data + '/';
                  document.forms[0].data.value = data;
                  return true;
              }
         }
//-->
</script>
<nav class="nav">
<ul>

<li class="drop"><a href="#"></a>
			<ul class="dropdown">				
</ul>
<li><a href="init.php">Home</a></li>
<li><a href="resumotecnologia.php">Resumo</a></li>							
<li><a href="detalhamento_geral.php">Detalhamento</a></li>	
<li><a href="lista_registro.php">Excluir</a></li>													
<li><a href="logout.php">Sair</a></li>							

</li>
</ul>
</nav>

            <br>
                    <h1 class="title has-text-grey">BANCO DE HORAS</h1>
					<h2 class="title has-text-grey"><font size=4><center>[Tecnologia da Informação]</font></h2>                   				


                    <div class="box">
					<p align=left>					
				   <img src=css/logo.png><br></p>
				   <center>

                   <?php
print '<font size=2 color=black>';
//criar a conexão com o banco

include "sql.php";



if(isset($_POST['done'])){   

    $usuario_consulta = $_POST['usuario_consulta'];
    
    if(empty($usuario_consulta)){

        $erro = "Aten��o, voc� deve preencher o campo Consulta";

    }else{        

       //$sql = mysql_query("SELECT str_to_date(data, '%d/%m/%Y') data1,data,nome,hora_inicio,hora_final,descricao,horas_baixa,faixa,data_criacao,usuario,ip FROM `banco_horas` where NOME = '$usuario_consulta' ORDER BY data1,hora_inicio ") or die(mysql_error());
		 $sql = mysql_query("SELECT str_to_date(data, '%d/%m/%Y') data1,data,nome,hora_inicio,hora_final,descricao,horas_baixa,faixa,data_criacao,usuario,ip FROM `banco_horas` where NOME = '$usuario_consulta' ORDER BY data1,hora_inicio ") or die(mysql_error());
            if($sql){

                $erro2 = "Pesquisa Feita  com sucesso!";

              } else{

                  $erro = "N�o foi possivel  recuperar os dados";

              }

    }

}

?>



<form name="form1" action="detalhamento_geral.php" method="POST" style="padding-top:40px;">

<?php

if(isset($erro)){

    print '<div style="width:80%; background:red; color:Black; padding: 5px 0px 5px 0px; text-align:center; margin: 0 auto;">'.$erro.'</div>';

}


if(isset($erro2)){

    print '<div style="width:80%; background:green; color:Black; padding: 5px 0px 5px 0px; text-align:center; margin: 0 auto;">'.$erro2.'</div>';

}
?>

<table>

<thead>

<tr>


</tr>

</thead>

<tbody>




<td><select name="usuario_consulta" class="input is-large" id="usuario_consulta">
<option>SELECIONE</option>
<option>VANDERLEI</option>
<option>ESTAGIARIO</option>
</select>
</td>


<td><input type="submit" value="Pesquisar" class="button is-block is-link is-large is-fullwidth" /><input type="hidden" name="done"  value="" /></td>
</tr>


</tbody>

</table>

</form>

</font>

<?php 
// INICIO DA CONSULTA PERSONALIZADA

   include "sql.php";//conex�o com o banco de dados   
   @mysql_select_db($db);//selecione o banco de dados
   
	
           $sqltudo = mysql_query("SELECT str_to_date(data, '%d/%m/%Y') data1,data,nome,hora_inicio,hora_final,descricao,horas_baixa,faixa,data_criacao,usuario,id FROM `banco_horas` where NOME = '$usuario_consulta' ORDER BY id")  or die(mysql_error()); 
           $colunas = mysql_num_rows($sqltudo);         
	   print'<br>';		
	   print'<br>';		   	
       print'<table border="1"   bordercolor="#00BFFF" >';
	   print'<tr>';
	   print'<td><b>ID</td>';
	   print'<td><b>NOME</td>';
	   print'<td><b>HORA INICIO</td>';
	   print'<td><b>HORA FINAL</td>';
	   print'<td><b>TOTAL HORAS</td>';
	   print'<td><b>DESCRICAO</td>';
	   print'<td><b>TIPO</td>';
	   print'<td><b>DATA</td>';	
	   print'</tr></b>';

           for($j = 0; $j < $colunas; $j++){/*caso no mesmo dia tenha mais eventos continua imprimindo */
           $id = @mysql_result($sqltudo, $j, "id");/*pegando os valores do banco referente ao evento*/
           $nome = @mysql_result($sqltudo, $j, "nome");
		   $hora_inicio = @mysql_result($sqltudo, $j, "hora_inicio");
           $hora_final = @mysql_result($sqltudo, $j, "hora_final");		   
		   $total_horas = $hora_final-hora_inicio;
           $descricao = @mysql_result($sqltudo, $j, "descricao");           
		   $tipo = @mysql_result($sqltudo, $j, "horas_baixa");           
		   $faixa = @mysql_result($sqltudo, $j, "faixa");           
           $data = @mysql_result($sqltudo, $j, "data");
		   $data_criacao = @mysql_result($sqltudo, $j, "data_criacao");
		   $usuario = @mysql_result($sqltudo, $j, "usuario");
		   $ip = @mysql_result($sqltudo, $j, "ip");
           				
		   $horaini = strtotime($hora_inicio)."<br>"; /*Transformando as horas em segundos*/
		   $horafin = strtotime($hora_final); /*Transformando as horas em segundos*/
           $total = $horafin - $horaini; /*Resultado em segundos*/
		   $hora_trabalhada = ($total/60)/60; /*Convertendo os segundos para horas*/
		   
	/*print '<table border=1>';/*monta a tabela */

	   print'<tr>';
	   print '<td>'.$id.'	</td>';
	   print '<td>'.$nome.'</td>';
	   print '<td>'.$hora_inicio.'</td>';
	   print '<td>'.$hora_final.'</td>';	   
	   print '<td>'.number_format($hora_trabalhada,2,'.','').'</td>';	
	   print '<td>'.$descricao.'</td>';
	   print '<td>'.$tipo.'</td>';
	   
	   if ($tipo =='FOLGA'){	   
		$horas_folga = number_format( $horas_folga + $hora_trabalhada,2,'.','');
		$faixa = '-';
		
	   }
	   if ($tipo =='BANCO_HORAS'){
		  
			
				$horas_acumuladas = number_format(( $horas_acumuladas + $hora_trabalhada),2,'.','');
				$horas_60 = ($horas_60 +$hora_trabalhada);
				$hora_s_acrescimo = ($hora_s_acrescimo  + $hora_trabalhada);
			
	   }
				print '<td>'.$data.'</td>';	   
				print '</tr>';	
           }
				print'</table>';

// FIM DA CONSULTA PERSONALIZADA

?>


<?php
print '<br>';

print '<font color=green size=4>';
print '<i>';
print 'Calculo de Horas:';
print $usuario_consulta;
print '</i>';
print '<font color=grow size=4>';
print'<br>';
print 'Total Horas Acumuladas:';
print '<font color=blue>';
print $horas_acumuladas;
print'<br>';
print '<font>';
print '<font color=grow size=4>';
print 'Total de Horas Folga:';
print '<font color=blue>';
print $horas_folga;
$saldo_horas =($horas_acumuladas-$horas_folga);
print '</font>';
print'<br>';

if ($saldo_horas >= 0 ){
	print '<font color=grow size=4>';
	print 'Saldo de Horas:';
	print '</font>';
	print '<font color=green size=4>';
	print $saldo_horas; 
	print '</font>';
}

if ($saldo_horas < 0 ){
	print '<font color=grow size=4>';
	print 'Saldo de Horas:';	
	print '<font color=red size=4>';
	print $saldo_horas;
	print '</font>';
}
print '<hr>';
print '<i>';
print '<font color=green size=4>';
?>

<br>




					</div>
                </div>
            </div>
        </div>
  
    </section>
	

</body>
</html>
